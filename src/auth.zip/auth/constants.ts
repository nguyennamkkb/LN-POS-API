export const jwtConstants = {
    secret: 'ntt908QTqppr913jcRcm',
  };